const express = require('express'); //Import the express dependency
const app = express();              //Instantiate an express app, the main work horse of this server
const port = 5000;                  //Save the port number where your server will be listening
const path = require("path");
const bodyParser = require('body-parser');

const fetch = require('node-fetch');
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(express.static('public'));
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
 extended: true}));
const dotenv = require('dotenv');
dotenv.config(); 
const axios = require('axios');


const toronto = `https://api.openweathermap.org/data/2.5/weather?id=6087824&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
const rio = `https://api.openweathermap.org/data/2.5/weather?id=3451190&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
const manhattan = `https://api.openweathermap.org/data/2.5/weather?id=4274994&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
const monte = `https://api.openweathermap.org/data/2.5/weather?id=3441575&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
const paris = `https://api.openweathermap.org/data/2.5/weather?id=6618607&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
const berlin = `https://api.openweathermap.org/data/2.5/weather?id=7290253&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
const rome = `https://api.openweathermap.org/data/2.5/weather?id=3169070&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
const cairo = `https://api.openweathermap.org/data/2.5/weather?id=360630&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
const seoul = `https://api.openweathermap.org/data/2.5/weather?id=1835847&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
const shanghai = `https://api.openweathermap.org/data/2.5/weather?id=1796236&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
const tokyo = `https://api.openweathermap.org/data/2.5/weather?id=1850147&units=metric&appid=1c45a9075c113172215a0ac5897b9966`;
//Idiomatic expression in express to route and respond to a client request
app.get('/', (req, res) => {        //get requests to the root ("/") will route here

    
    res.sendFile(path.join(__dirname+"/login.html"));      //server responds by sending the index.html file to the client's browser
                                                        //the .sendFile method needs the absolute path to the file, see: https://expressjs.com/en/4x/api.html#res.sendFile 
});
app.get('/homepage', function (req, res) {
    res.sendFile(__dirname + '/homepage.html')
  })
  
  app.post('/register', function (req, res) {
    console.log(req.body)
    res.redirect('/homepage')
  })
  app.get('/sign_up', function (req, res) {
    res.sendFile(__dirname + '/sign_up.html')
  })
  
  app.post('/reg', function (req, res) {
    console.log(req.body)
    res.redirect('/sign_up')
  })
  app.get('/login', function (req, res) {
    res.sendFile(__dirname + '/login.html')
  })
  
  app.post('/rrr', function (req, res) {
    console.log(req.body)
    res.redirect('/login')
  })
app.get('/toronto', async (req,res)=>{
    
    try{
        const result = await fetch(toronto);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});
app.get('/seoul', async (req,res)=>{
    
    try{
        const result = await fetch(seoul);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});
app.get('/rio', async (req,res)=>{
    
    try{
        const result = await fetch(rio);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});
app.get('/manhattan', async (req,res)=>{
    
    try{
        const result = await fetch(manhattan);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});
app.get('/monte', async (req,res)=>{
    
    try{
        const result = await fetch(monte);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});
app.get('/paris', async (req,res)=>{
    
    try{
        const result = await fetch(paris);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});
app.get('/berlin', async (req,res)=>{
    
    try{
        const result = await fetch(berlin);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});
app.get('/rome', async (req,res)=>{
    
    try{
        const result = await fetch(rome);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});
app.get('/cairo', async (req,res)=>{
    
    try{
        const result = await fetch(cairo);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});
app.get('/shanghai', async (req,res)=>{
    
    try{
        const result = await fetch(shanghai);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});
app.get('/tokyo', async (req,res)=>{
    
    try{
        const result = await fetch(tokyo);
        let response = await result.json();
        
        res.send(response);
    }
    catch(err){
        console.log(err);
    }
  
  
});



app.listen(port, () => {            //server starts listening for any attempts from a client to connect at port: {port}
    console.log(`Now listening on port ${port}`); 
});